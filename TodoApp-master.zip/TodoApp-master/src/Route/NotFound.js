import React from "react";

function NotFound(){
    return(
        <>
            <h2>404</h2>
            <h4>This page isnt found</h4>
        </>
    )
}

export default NotFound