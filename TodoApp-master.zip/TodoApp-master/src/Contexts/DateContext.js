import React from "react";

const DateContext = React.createContext({})

export default DateContext