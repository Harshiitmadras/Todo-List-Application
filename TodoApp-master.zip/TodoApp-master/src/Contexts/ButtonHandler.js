import React  from "react";

let BtnContext = React.createContext({})

export default BtnContext